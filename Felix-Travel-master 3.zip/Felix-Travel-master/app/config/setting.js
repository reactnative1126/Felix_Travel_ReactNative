/**
 * Basic Setting Variables Define
 */
export const BaseSetting = {
    name: "FelixPro",
    displayName: "FelixPro",
    appVersion: "1.0.0"
};
