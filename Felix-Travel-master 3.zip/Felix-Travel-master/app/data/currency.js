const CurrencyData = [
    { id: "1", currency: "USD", checked: true },
    { id: "2", currency: "VND", checked: false },
    { id: "3", currency: "KWR", checked: false }
];

export { CurrencyData };
