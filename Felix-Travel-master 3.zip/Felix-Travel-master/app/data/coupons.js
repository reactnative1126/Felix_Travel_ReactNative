const CouponsData = [
    {
        id: "1",
        name: "Proxeloca Hotel",
        code: "CLMVBG",
        description: "Save $99 for first item",
        valid: "Valid Time: Dec 22, 2018 - Dec 29, 2018",
        remain: "Remain 3 days"
    },
    {
        id: "2",
        name: "Sunrise Tours",
        code: "HROJSF",
        description: "Save $99 for first item",
        valid: "Valid Time: Dec 22, 2018 - Dec 29, 2018",
        remain: "Remain 3 days"
    },
    {
        id: "3",
        name: "Kloor Tours",
        code: "IQ24-EUZP-IUGY",
        description: "Save $99 for first item",
        valid: "Valid Time: Dec 22, 2018 - Dec 29, 2018",
        remain: "Remain 3 days"
    }
];

export { CouponsData };
