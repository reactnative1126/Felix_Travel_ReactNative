const LanguageData = [
    {
        id: "1",
        language: "English",
        locale: 'en',
        checked: true
    },
    { id: "2", language: "Vietnames", locale: 'vi' },
    { id: "3", language: "Japanes", locale: 'ja' },
    { id: "4", language: "Korean", locale: 'ko' }
];

export { LanguageData };
